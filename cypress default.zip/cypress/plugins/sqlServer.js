const sql = require('mssql')



const connectionFunction = (config) => async (query) => {

    const pool = new sql.ConnectionPool(config)

    try {

        await pool.connect()

        const result = await pool.request().query(query)

        return result.recordset

    } catch (err) {

        console.error('Erro ao executar query SQL Server:', err)

        throw err

    } finally {

        pool.close()

    }

}



const connection01 = connectionFunction({

    user: process.env.SQL_USER,
    password: process.env.SQL_PASSWORD,
    server: process.env.SQL_SERVER,
    database: process.env.SQL_DATABASE,
    options: {
        encrypt: true,
        trustServerCertificate: true
    }

})



const connection02 = connectionFunction({

    user: process.env.SQL_USERDB,

    password: process.env.SQL_PASSWORDDB,

    server: process.env.SQL_SERVERDB,

    database: process.env.SQL_DATABASEDB,

    options: {

        encrypt: true,

        trustServerCertificate: true

    }

})



module.exports = { connection01, connection02 }