import * as ScriptSQL from '../fixtures/sqlCommands/sql';

Cypress.Commands.add('consulta01', () => {
  cy.task('teste01',ScriptSQL.tebela01());
});

Cypress.Commands.add('consulta02', () => {
  cy.task('teste02',ScriptSQL.tebela02());
});