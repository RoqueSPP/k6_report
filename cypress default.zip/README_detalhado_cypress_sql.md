# 🧠 Documentação Técnica - Integração Cypress com SQL Server

Este projeto realiza integração entre **Cypress** e **SQL Server**, permitindo executar queries diretamente em testes automatizados.

---

## 📘 1. Arquivo `cypress.config.js`
```js
const { defineConfig } = require("cypress");
require('dotenv').config();

module.exports = defineConfig({
  e2e: {
    setupNodeEvents(on, config) {
      // implement node event listeners here
      return require('./cypress/plugins/index')(on, config)
    },
  },
});
```

### 🔍 Explicação
- **require("cypress")** → Importa a função `defineConfig` que define a configuração principal do Cypress.
- **require('dotenv').config()** → Carrega variáveis de ambiente do arquivo `.env`.
- **module.exports = defineConfig({...})** → Exporta a configuração do Cypress para uso.
- **setupNodeEvents(on, config)** → Função usada para registrar eventos e plugins personalizados (neste caso, conecta ao `index.js` dentro de `cypress/plugins/`).

---

## 📘 2. Arquivo `index.js`
```js
const { connection01, connection02 } = require('./sqlServer')

module.exports = (on, config) => {
  on('task', {
    teste01: (query) => connection01(query),
    teste02: (query) => connection02(query)
  })
  return config
}
```

### 🔍 Explicação
- **require('./sqlServer')** → Importa as conexões com o banco de dados.
- **module.exports = (on, config)** → Função padrão de inicialização dos plugins do Cypress.
- **on('task', {...})** → Registra tarefas personalizadas que podem ser chamadas nos testes Cypress via `cy.task()`.
- **teste01 / teste02** → Cada função executa uma query SQL usando uma das conexões configuradas (`connection01` ou `connection02`).  
  Isso permite rodar comandos SQL diretamente durante os testes automatizados.

---

## 📘 3. Arquivo `sql.js`
```js
export function funcao01() {
  return `select * from dbo.tabela01`
}

export function funcao02() {
  return `select * from dbo.tabela02`
}
```

### 🔍 Explicação
- **funcao01()** → Retorna uma query SQL para consultar todos os registros da tabela `tabela01`.
- **funcao02()** → Retorna uma query SQL para consultar todos os registros da tabela `tabela02`.
Essas funções servem como *templates* de consultas reutilizáveis que podem ser chamadas em testes Cypress.

---

## 📘 4. Arquivo `sqlServer.js`
```js
const sql = require('mssql')

const connectionFunction = (config) => async (query) => {
    const pool = new sql.ConnectionPool(config)
    try {
        await pool.connect()
        const result = await pool.request().query(query)
        return result.recordset
    } catch (err) {
        console.error('Erro ao executar query SQL Server:', err)
        throw err
    } finally {
        pool.close()
    }
}

const connection01 = connectionFunction({
    user: process.env.SQL_USER,
    password: process.env.SQL_PASSWORD,
    server: process.env.SQL_SERVER,
    database: process.env.SQL_DATABASE,
    options: { encrypt: true, trustServerCertificate: true }
})

const connection02 = connectionFunction({
    user: process.env.SQL_USERDB,
    password: process.env.SQL_PASSWORDDB,
    server: process.env.SQL_SERVERDB,
    database: process.env.SQL_DATABASEDB,
    options: { encrypt: true, trustServerCertificate: true }
})

module.exports = { connection01, connection02 }
```

### 🔍 Explicação
- **sql = require('mssql')** → Importa a biblioteca oficial do SQL Server para Node.js.
- **connectionFunction(config)** → Cria uma função assíncrona que:
  1. Abre uma conexão (`sql.ConnectionPool(config)`);
  2. Executa a query recebida (`pool.request().query(query)`);
  3. Retorna o resultado (`result.recordset`);
  4. Fecha a conexão no `finally`.
- **connection01 / connection02** → São duas conexões independentes, cada uma com credenciais diferentes (obtidas do `.env`).
- **module.exports** → Exporta ambas as conexões para uso em `index.js`.

---

## ⚙️ Fluxo de Funcionamento

1. **O Cypress inicia** → `cypress.config.js` chama o plugin `index.js`.
2. **O `index.js` registra tasks personalizadas** (`teste01` e `teste02`).
3. **Durante um teste**, o Cypress pode chamar:
   ```js
   cy.task('teste01', funcao01())
   ```
   Isso executa a query SQL retornada por `funcao01()` no banco configurado em `connection01`.

---

## 🚀 Exemplo de Uso em Teste Cypress
```js

describe('Consulta SQL', () => {
  it('Executa uma query no banco de dados', () => {
    cy.task('teste01', funcao01()).then((result) => {
      expect(result).to.not.be.empty
    })
  })
})
```

---

## 🧩 Resumo
| Arquivo | Função Principal |
|----------|------------------|
| **cypress.config.js** | Configura o ambiente e integra os plugins. |
| **index.js** | Registra tasks personalizadas do Cypress. |
| **sql.js** | Define queries SQL prontas para uso. |
| **sqlServer.js** | Gerencia conexões e execução de queries no SQL Server. |

---

## 🧑‍💻 Autor
Gerado automaticamente via ChatGPT (GPT-5)  
Documentação detalhada dos arquivos Cypress + SQL Server.
