
const { connection01, connection02 } = require('./sqlServer')




module.exports = (on, config) => {

  on('task', {

    teste01: (query) => connection01(query),

    teste02: (query) => connection02(query)

  })



    return config

}