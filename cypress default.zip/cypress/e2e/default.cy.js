describe('template spec', () => {
  it('passes', () => {
    cy.TipoApiExterna().then((response)=>{
      cy.log(response)
    })
    cy.FileTabelaPreco().then((response)=>{
      cy.log(response)
  })
})
})