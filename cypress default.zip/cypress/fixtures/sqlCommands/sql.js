

export function funcao01() {
  return `select * from dbo.tabela01`
}

export function funcao02() {
  return `select * from dbo.tabela02`
}